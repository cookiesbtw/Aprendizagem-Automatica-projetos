from flask import Flask, request, jsonify
import pickle

app = Flask(__name__)

# Carregar modelos e vetorizador
modelos = {
    "random_forest": pickle.load(open('random_forest_model.pkl', 'rb')),
    "logistic_regression": pickle.load(open('Logistic_Regression_model.pkl', 'rb')),
    "decision_tree": pickle.load(open('Decision_Tree_model.pkl', 'rb'))
}
vectorizador = pickle.load(open('tfidf_vectorizer.pkl', 'rb'))

@app.route("/usage")
def usage():
    return jsonify(
        {
            "routes": {
                "/": {
                    "method": "GET",
                    "description": "Base route for the API."
                },
                "/predict/<model_name>/<text>": {
                    "method": "GET",
                    "description": "Prever o sentimento de um determinado texto usando um dos modelos",
                    "parameters": {
                        "model_name": "Diz que modelo usar (random_forest, logistic_regression, or decision_tree).",
                        "text": "Texto para análise"
                    }
                }
            }
        }
    )


@app.route('/predict/<model_name>/<text>', methods=['GET'])
def predict(model_name, text):
    # Transforma o texto
    text_vector = vectorizador.transform([text])

    # Escolher o modelo
    model = modelos.get(model_name, None)
    if not model:
        return jsonify({"error": "Modelo não encontrado."}), 400

    # Fazer previsão
    prediction = model.predict(text_vector)
    sentiment = 'positivo' if prediction[0] == 1 else 'negativo'
    return jsonify({'texto': text, 'sentimento': sentiment})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
